# -*- coding: utf-8 -*-
"""

@author: zhengjian.002@163.com
"""

import math
import numpy as np
import conformalmapping as cm


def kernelfunction(Type, u, v, p):
    # u, v are array like; p is parameter for kernels; type=1:RBF kernel, type=2: RBF with conformal 
    if(Type==1):     #RBF 
       
        temp = u-v
        return pow(math.e,(-np.dot(temp,temp)/(p**2)))
    
    
    if(Type==2):    
        temp = u-v

        cm_temp=cm.conformal_mapping(temp)

        return pow(math.e,(-np.dot(cm_temp,cm_temp)/(p**2)))
    
        

    
