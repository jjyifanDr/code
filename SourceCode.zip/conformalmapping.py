
"""

@author: zhengjian.002@163.com
"""

import numpy as np


N=1000    #auss_integral approximation order   1<=N, defaut value=1000

def find_points(points):
    '''
    The function finds two points
    '''
    n1_point = [p for p in np.arange(2, len(points)-2, 2)]
    n2_point = [p for p in range(len(points)) if p not in n1_point]

    n1_points = np.asarray(points)[n1_point]
    n2_points = np.asarray(points)[n2_point]
    return n1_points, n2_points


def save_points(points):
    '''
    The function saves points using list manner
    '''
    result = []
    for i in range(0, len(points)-2, 2):
        result.append(np.roll(points, -i))
    return result


def create_matrix_Q(points):
    '''
    The function creates a Q matrix
    '''
    result = list([])
    for k in range(1, len(points)-2, 2):
        result.append( [points[k], points[k+1]])
    return result


def create_matrix_P(points):
    '''
    This function creates a P matrix
    '''
    result=list([])
    for k in range(0, len(points)-2, 2):
        result.append( [points[k], points[k+1]])
    return result




def gauss_integral(n1_points_regions, n2_points_regions, lim, n=N):
    '''
    Gauss_integral approximates the regions surrounded by points
    '''
    x = np.cos((2*np.arange(n)+1)*np.pi/(2*n))*(lim[1]-lim[0])*0.5+np.mean(lim)
    y = np.ones(x.shape)
    for p in n1_points_regions:
        y *= np.sqrt(np.abs(x-p)+1e-100)
    for p in n2_points_regions:
        y /= np.sqrt(np.abs(x-p)+1e-100)
    return np.sum(y)*np.pi/n




def conformal_mapping(elements):

        points =elements 
        shape_matrix = int((len(points) )/2)
        Q_mat = np.zeros((shape_matrix, shape_matrix))
        P_mat = np.zeros((shape_matrix, shape_matrix))
 

        ''' 
        initialization matrix P, Q
        '''
        Q_matrix = create_matrix_Q(points)
        P_matrix = create_matrix_P(points)
 
 
        for i in range(shape_matrix-1):
            
            counter_P=0    # variable swap

            f_points = save_points(points)[i]
            point_n1, point_n2 = find_points(f_points)

 
    

            for j in range(shape_matrix-1):
   
                '''
                covert format into list
                '''
                list_point_n1_Q = list(point_n1)
                list_point_n2_Q = list(point_n2)

                list_point_n1_P = list(point_n1)
                list_point_n2_P = list(point_n2)
                
                
                '''
                read Matrix Q, P
                '''
                lim_Q = Q_matrix[j]
                lim_P = P_matrix[j]

 
                Q_mat[j][i] = gauss_integral(list_point_n1_Q, list_point_n2_Q, lim_Q, n=N)
                P_mat[j][i] = counter_P - gauss_integral(list_point_n1_P, list_point_n2_P, lim_P, n=N)
                
                counter_P = P_mat[j][i]
 
        result = np.dot(Q_mat, P_mat)


        return result
    
    
   